package com.hospital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalFrontendApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(HospitalFrontendApplication.class, args);
	}

}
